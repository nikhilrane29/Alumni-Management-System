<?php session_start();
if(empty($_SESSION['id']));
header('Location:Admin login.php');

?>
<!DOCTYPE html>
<html>
<body>
<div style="width:150px;margin:auto;height:500px;margin-top:300px"></div>
<?php
include('adloginconnect.php');
session_destroy();
echo '<meta http-equiv="refresh" content="2;url=Admin login.php">';
echo '<progress max=100><strong>progress: 60%done.</strong></progress><br>';

echo '<span class="itext">Logging out please wait............!</span>';
?>

</body></html>