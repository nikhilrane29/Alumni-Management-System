<?php
$dbhost='localhost';
$dbname='alumni';
$dbusername='root';
$dbpass='';
$mysqli=mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);

?>