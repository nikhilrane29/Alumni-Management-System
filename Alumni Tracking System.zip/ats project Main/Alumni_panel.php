

<!DOCTYPE html>
<html>
  <head>
    <title>Successfully login</title>

	
	<!-- include css file here-->
    <link rel="stylesheet" href="css/style.css"/>
   
   <script type="text/javascript">
	
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-43981329-1']);
	_gaq.push(['_trackPageview']);
	(function () {
	var ga = document.createElement('script');
	ga.type = 'text/javascript';
	ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

	var s = document.getElementsByTagName('script')[0];
	s.parentNode.insertBefore(ga, s);
	})();
	//]]>
	</script>
   
  </head>
<body>
<center>You are Successfully Login. </br></br> 
	
	
	<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		.topnav-right {
        float: right;
        }
		</style>
	
		
		 <div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
          <a href="Alumni event show.php">Event Details</a>
		  <a href="Alumni_show reg.php">Register Student</a>
          <a href="Alumni show upcomming event.php">Upcomming Event</a>
		  <div class="topnav-right">
             <a href="home.php">Log Out</a>
			 </a>
		</div>
		 </div>
	
		<div style="padding-left:16px">
		 <h5>Welcome to Alumni Panel....!</h5>
		</div>
		

		<div class="container">
  <img src="./images/local_alumni.png" alt="" width="300" height="300">
		
		</div>
		
	
</body>
</html>