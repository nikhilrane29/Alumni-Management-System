<?php
//getting i variable value using GET method
$Id = $_GET['i'];
echo $Id;
$con = mysqli_connect("localhost","root","","alumni");
mysqli_query($con,"delete from info where Id='$Id'");
//After Delete record then call select.php
header("location:select.php");

?>