<!DOCTYPE html>
<html lang="en">
<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
 <link rel="stylesheet" type="text/css" href="css/style.css">
 <link rel="stylesheet" type="text/css" href="css/Alumni login.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>
	
	<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>
	
		
		 <div class="topnav"> 
         <a class="active" href="index.php">Home</a> 
       <a href="Alumni event show.php">Event Details</a>
		   <a href="Alumni_show reg.php">Alumni</a>
       <a href="Alumni show upcomming event.php">Upcomming Event</a>



		</div>
		
		
		</div>
</header>
<!----------------------------------------------------------------------------------------------->
<div class="container">
  <h2>Upcomming Events</h2>
  <table class="table">
    <thead>
      <tr>
        <th>Event Name</th>
        <th>Event Date</th>
        <th>Organizer email</th>
        <th>Time</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Milestone</td>
        <td>22 jun 2021</td>
        <td>def@somemail.com</td>
        <td>11:00 Am</td>

      </tr>      
      <tr class="success">
        <td>oracle apex training online</td>
        <td>*****</td>
        <td>john@example.com</td>
        <td>*********</td>
      </tr>
      <tr class="danger">
        <td>cyber security training </td>
        <td>*****</td>
        <td>mary@example.com</td>
        <td>********</td>

      </tr>
      <tr class="info">
        <td>Learn Oracle RAC Online Training</td>
        <td>*****</td>
        <td>july@example.com</td>
        <td>******</td>

      </tr>
      <tr class="warning">
        <td>Triton AP-Web Online Training</td>
        <td>*****</td>
        <td>bo@example.com</td>
        <td>*******</td>

      </tr>
      <tr class="active">
        <td>Sitecore Training</td>
        <td>*****</td>
        <td>act@example.com</td>
        <td>*******</td>

      </tr>
    </tbody>
  </table>
</div>

      
<!---------------------------------------------------------------------------------------------------------------->
<script type="text/javascript" src="javascript/script.js"></script>
<script type="text/javascript" src="New Alumni.php"></script>
<footer class="mainFooter">
	<p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>
	
</footer>

</body>
</html>