-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2021 at 07:27 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumni`
--

-- --------------------------------------------------------

--
-- Table structure for table `eshow`
--

CREATE TABLE `eshow` (
  `oemail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `event show`
--

CREATE TABLE `event show` (
  `date` varchar(6) NOT NULL,
  `time` varchar(30) NOT NULL,
  `venue` varchar(50) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `omobile` varchar(50) NOT NULL,
  `oemail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `event_poster`
--

CREATE TABLE `event_poster` (
  `id` int(11) NOT NULL,
  `image` blob NOT NULL,
  `ename` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `evshow`
--

CREATE TABLE `evshow` (
  `id` int(200) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `venue` text NOT NULL,
  `oname` varchar(100) NOT NULL,
  `omobile` varchar(20) NOT NULL,
  `oemail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `evshow`
--

INSERT INTO `evshow` (`id`, `date`, `time`, `venue`, `oname`, `omobile`, `oemail`) VALUES
(1, '2021-08-12', '2pm', 'mlk', 'nikhil', '11111111', 'jjjjjj232@gmail.com'),
(2, '2021-08-12', '5pm', 'jalgaon', 'akshay p', '1212211', 'yyyyyy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `Id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `cpwd` varchar(50) NOT NULL,
  `dname` varchar(50) NOT NULL,
  `addyr` text NOT NULL,
  `passyr` text NOT NULL,
  `clocation` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `dob` date NOT NULL,
  `email` text NOT NULL,
  `phno` int(50) NOT NULL,
  `award` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`Id`, `fname`, `uname`, `pwd`, `cpwd`, `dname`, `addyr`, `passyr`, `clocation`, `address`, `dob`, `email`, `phno`, `award`) VALUES
(2, 'Akshay p', 'akp22', '33333', '33333', 'computer', '2018', '2022', 'mlk', 'pune', '2021-07-03', 'nra671@gmail.com', 254666666, 'yes'),
(4, 'Akshay p', 'amn44', '123', '123', 'computer', '2018', '2022', 'mlk', 'jalgaon', '2021-06-20', 'nrane1@gmail.com', 55555, 'iiii');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uname` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `password`) VALUES
('Niks11', 'Nikhil1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event_poster`
--
ALTER TABLE `event_poster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evshow`
--
ALTER TABLE `evshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
