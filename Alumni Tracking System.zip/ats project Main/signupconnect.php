<?php  
     $fname="";
     $uname="";
     $pwd="";
     $cpwd="";
     $dname="";
     $addyr="";
     $passyr="";
     $clocation="";
     $address="";
     $dob="";
     $email="";
     $phno="";
     $award="";
//connection
	$con = mysqli_connect("localhost","root","","alumni");
	if(isset($_POST['reg'])){
        $fname = $_POST['fname'];
        $uname = $_POST['uname'];
        $pwd = $_POST['pwd'];
        $cpwd = $_POST['cpwd'];
        $dname = $_POST['dname'];
        $addyr = $_POST['addyr'];
        $passyr = $_POST['passyr'];
        $clocation = $_POST['clocation'];
        $address = $_POST['address'];
        $dob = $_POST['dob'];
        $email = $_POST['email'];
        $phno = $_POST['phno'];
        $award = $_POST['award'];

        $query = "insert into info(fname,uname,pwd,cpwd,dname,addyr,passyr,clocation,address,dob,email,phno,award) values('$fname','$uname','$pwd','$cpwd','$dname','$addyr','$passyr','$clocation','$address','$dob','$email','$phno','$award')";
        $result = mysqli_query($con,$query);
        echo 'Registration Successfull';
        
        header("location:Alumni login.php");
    }
	
    
    
    

	


?>