<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>upload post</title>
    <style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>
<body>
<!-- --------------------------------nav bar----------------- -->
<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>
	
		
		 <div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
		  <a href="upload.php">Upload post</a>
		  <a href="update_event.php">Update Event</a>
		  <a href="select.php">Register student</a>
		  <a href="Event show.php">Event Show</a>



		</div>
		
		
		</div>
		

<!-- --------------------------------------------------------------------------------- -->
    <link rel="stylesheet" href="./css/upload.css" type="text/css">

    <div class="body-content">
	<form action="" method="POST" enctype="multipart/form-data">
        <div class="module">
            <h1 style="color:rgb(32, 8, 8)">Upload Your Poster</h1>

<input type="file" name="image" id="image" hidden="hidden" />
<button type="button" id="custom-button">CHOOSE A FILE</button>
<span id="custom-text">No file chosen, yet.</span><br><br>
<p style="color:rgb(32, 20, 20)">Event Name:</p>
<input type="text" placeholder="Enter Event Name"   name="ename" required="true"></p>

<!-- <p style="color:rgb(32, 20, 20)">Time Of Event</p>
<input type="number" placeholder="Time"   name="time" required="true"></p>
<input type="text" placeholder="Venue"   name="venue" required="true"></p>
<input type="text" placeholder="Organizer Name"   name="oname" required="true"></p>
<input type="number" placeholder="Organizer Mobile No"   name="omobile" required="true"></p>
<input type="email" placeholder="Organizer Email ID"   name="oemail" required="true"></p> -->
<p style="color:rgb(238, 141, 15)"><b></b>Notes:</b>Upload Only Poster in jpg Extension</p>

<input type="submit" value="Submit" name="upload" class="btn btn-block btn-primary" />
</form>

<!-- choose file js connection -->
<!-- <script type="text/javascript">
const realFileBtn = document.getElementById("image");
const customBtn = document.getElementById("custom-button");
const customTxt = document.getElementById("custom-text");

customBtn.addEventListener("click", function() {
  realFileBtn.click();
});

realFileBtn.addEventListener("change", function() {
  if (realFileBtn.value) {
    customTxt.innerHTML = realFileBtn.value.match(
      /[\/\\]([\w\d\s\.\-\(\)]+)$/
    )[1];
  } else {
    customTxt.innerHTML = "No file chosen, yet.";
  }
}); -->
</script>
</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'alumni');
if(isset($_POST['upload']))
{
$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
$ename = $_POST['ename'];
$query = "INSERT INTO 'event_poster' ('image',ename') VALUES ('$file','ename')";
$query_run = mysqli_query($connection,$query);

if($query_run)
{
	echo '<script type="text/javascript"> alert("Image Profile Uploaded"> </script>';
}
else{

	echo '<script type="text/javascript"> alert("Image Profile Not Uploaded"> </script>';

}
}





?>




