<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<title>Event Update show</title>
<style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>
<body>

<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>

<div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
		  <a href="upload.php">Upload post</a>
		  <a href="update_event.php">Update Event</a>
		  <a href="select.php">Register student</a>
		  <a href="Event show.php">Event Show</a>



		</div>
		


<div class="container">
<h1 style="color:greay" align="center">Event Details</h1> 
  <table class="table">
    <thead>
      <tr class="danger">
        <th>ID</th>
        <th>Date</th>
        <th>Time</th>
        <th>venue</th>
        <th>oname</th>
        <th>omobile</th>
        <th>oemail</th>
      </tr>
    </thead>
  <?php
$conn = mysqli_connect('localhost','root','','alumni');
if($conn-> connect_error){
  die("connection failed:". $conn-> connect_error);

}
$sql = "SELECT id, date, time, venue, oname, omobile, oemail from evshow";
$result = $conn-> query($sql);
if ($result-> num_rows > 0) {
  while ($row = $result-> fetch_assoc()){
    echo "<tr><td>". $row["id"] ."</td><td>". $row["date"] ."</td><td>". $row["time"] ."</td><td>". $row["venue"] ."</td><td>". $row["oname"] ."</td><td>". $row["omobile"] ."</td><td>". $row["oemail"] ."</td><tr>";
  }
  echo "</table>";
  }
  else {
    echo 
    "0 result";
  }
?>



  
  </table>
</body>
</html>