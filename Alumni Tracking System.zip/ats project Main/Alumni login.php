<?php  
	$conn = mysqli_connect("localhost","root","","alumni");
	$msg = "";
	if(isset($_POST["submit"])){
		$username = $_POST["username"];
		$password = $_POST["password"];
		
		$sql = mysqli_query($conn,"SELECT * FROM info WHERE uname='$username' AND pwd='$password'");

		if(mysqli_num_rows($sql)>0){
			header("Location:Alumni_panel.php");
		}else{
			$msg = "Plese Enter Correct Username or Password";
		}

	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

 <link rel="stylesheet" type="text/css" href="css/style.css">
 <link rel="stylesheet" type="text/css" href="css/Alumni login.css">

</head>
<body class="body">
<header class="mainheader">
<img src="images/logo.png">
	<content id="search">
		<form>
  		<input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
		</form>

	</content>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="About us.php">About us</a></li>
			<li><a href="Alumni login.php">Alumni Login</a></li>
			<li><a href="New Alumni.php">New Alumni</a></li>
			<li><a href="Admin login.php">Admin Login</a></li>
            <li><a href="contact.php">Contact</a></li>

		</ul> 
	</nav>
</header>
<!----------------------------------------------------------------------------------------------->

	 <style>
    *{
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: sans-serif;
    }
    body {
        /* background: #d8dbf0; url('d.jpg') no-repeat center fixed; */
        background-size: cover;
    }
.container {
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    /* background: linear-gradient(to left top, rgba(202, 184, 184, 0.6), rgba(10, 10, 10, 0.1)); */
}
.form-container {
    background: linear-gradient(to left top, rgba(0, 0, 0, .5), rgba(10, 10, 10, 0.5));
    padding: 25px 30px;
    border-radius: 24px;
    border-top: 1px solid #fff;
    border-right: 1px solid #000;
    border-bottom: 1px solid #000;
    border-left: 1px solid #fff;
}
.avatar {
    position: absolute;
    margin-left: 95px;
    margin-top: -55px;
}
h2 {
    margin: 25px 0;
    text-align: center;
}
h2, .avatar, label {
    color: #fff;
}
label {
    display: block;
    margin: 15px 0 5px 0;
    font-size: 13px;
}
input[type=text], input[type=password] {
    width: 250px;
    height: 30px;
    padding-left: 10px;
    border-radius: 4px;
    background-color: rgba(0, 0, 0, .2);
    color: #ccc;
    border-top: 1px solid #000;
    border-right: 1px solid #fff;
    border-bottom: 1px solid #fff;
    border-left: 1px solid #000;
}
input[type=text]:focus, input[type=password]:focus {
    background-color: rgba(0, 0, 0, .5);
}
input[type=checkbox], button {
    cursor: pointer;
}
button {
    background: none;
    width: 100%;
    height: 35px;
    margin-top: 20px;
    border-top: 2px solid #fff;
    border-right: 2px solid #000;
    border-bottom: 2px solid #000;
    border-left: 2px solid #fff;
    color: #fff;
    transition: .3s;
}
button:active {
    border-top: 2px solid #000;
    border-right: 2px solid #fff;
    border-bottom: 2px solid #fff;
    border-left: 2px solid #000;
}
.container p {
    color: #ccc;
    margin-top: 20px;
}
.container a {
    color: #fff;
    text-decoration: none;
}
.container a:hover {
    text-decoration: underline;
}
</style>

</head>
<body style="background-image:url(n1.png)">

<div class="container">
    <div class="form-container">
        <div class="avatar"><i class="fa fa-user-circle fa-4x" aria-hidden="true"></i></div>
    
		<h2>Alumni Login</h2>
        <p><?php echo $msg; ?></p>
        <form method="post" action="">
            <label for="username">Username:</label>
            <input type="text" name="username" placeholder="Enter username" required />
            <label for="password">Password:</label>
            <input type="password" name="password" placeholder="Enter password" required />
            <label><input type="checkbox" checked /> Remember me</label>
            <button type="submit" name="submit">Sign In</button><br><br>
			<a href="#">Forgot Password</a> 
        </form>
    </div>
	
</div>
<!---------------------------------------------------------------------------------------------------------------->
<script type="text/javascript" src="javascript/script.js"></script>
<script type="text/javascript" src="Sign In.php"></script>
<footer class="mainFooter">
	<p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>
	
</footer>

</body>
</html>