<!DOCTYPE html>
<html lang="en">
<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Keywords" content="SSBT COET BAMBHORI,JALGAON">
 <meta name="author" content="---">
 <link rel="stylesheet" type="text/css" href="css/style.css">
<script src="javascript/js.js="></script>
<style>
	body{
	background-image: url('./images/bg3.jpg');
	margin:0;
	padding: 0;
	font-family: 'Montserrat', sans-serif;
}
.container{
	width: 100%;
	height: 100vh;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
	background-image: url(bg3.jpg);
	background-size: cover;
	background-position: center center;
	color: #fff;
	padding: 0
}
.nav{
	display: flex;
	justify-content: space-between;
	width: 90%;
	margin:10px;
}
.nav span{
	margin-left: 20px;
}
.about-us{
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	flex-direction: column;
}
.who-we-are{
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
}
.who-we-are span{
	width: 60%;
	align-items: center;
text-align: center;
}
.cards{
	display: flex;
	justify-content: center;
	align-items: center;
	margin:10px;
	/* flex-wrap: wrap; */
}
.card-img{
	border-radius: 5px;
	width: 100%;
	height: 12rem;

}
.cards .card{
	width: 16rem;
	margin: 20px;
}
.card p{
	font-size: 14px;
}
.social-media{
	width: 90%;
	display: flex;
	justify-content: flex-end;
}
.social-media i{
	margin:10px;
}
.active{
	border-bottom: 1px solid #fff;
}
.card-img1{
/*	width: 100%;
	height: 12rem;*/
	background-image: url('./images/01.jpg');
	background-size: cover;
	background-position: center center;
}
.card-img2{
/*	width: 100%;
	height: 12rem;*/
	background-image: url('./images/021.jpg');
	background-size: cover;
	background-position: center center;
}
.card-img3{
	/*width: 100%;
	height: 14rem;*/
	/* bottom: -1; */
	background-image: url('./images/031.jpg');
	background-size: cover;
	background-position: center center;
}
.card-img4{
/*	width: 100%;
	height: 12rem;*/
	background-image: url('./images/041.jpg');
	background-size: cover;
	background-position: center center;
}
.logo{
	font-family: 'Dancing Script',cursive;
	font-size: 24px;
}


</style>

</head>
<body class="body">
<header class="mainheader">
	<img src="./images/logo.png">
	<content id="search">
		<form>
  <input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
</form>

	</content>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="About us.php">About us</a></li>
			<li><a href="Alumni login.php">Alumni Login</a></li>
			<li><a href="New Alumni.php">New Alumni</a></li>
			<li><a href="Admin login.php">Admin Login</a></li>
			<li><a href="contact.php">Contact</a></li>

			
		</ul> 
	</nav>
  

	<div class="about-us">
		<div class="who-we-are">
			<h2>About College</h3>
		<p><span><b>Shram Sadhana Bombay Trust runs the COLLEGE of ENGINEERING & TECHNOLOGY at Bambhori, Jalgaon,</b> which is the one of the important industrial town & district headquarters of Maharashtra state.
			<b> SSBT COET </b>campus is lush green spread over 25 acres area and located on the bank of River Girna.The campus is well equipped with important amenities such as classrooms, drawing halls, laboratories,
			  seminar halls, library, computer center, workshop, hostels, canteens, indoor as well as outdoor sports facilities etc.</span></p>
		</div>
		<div class="cards">
			<div class="card">
				<div class="card-img card-img1">
					
				</div>
				<div class="card-body">
					<h3>Vision of the Institute</h3>
					<p>Today we carry the flame of quality education, knowledge and progressive technology for global societal development; 
						tomorrow the flame will glow even brighter.<br><br><br><br><br></p>
				</div>
				</div>
		
		
		<div class="card">
				<div class="card-img card-img2">
				</div>
				<card class="card-body">
					<h3>Mission of the Institute</h3>
					
					<p>To provide conducive environment for preparing competent, value added and 
						patriotic engineers of integrity of par excellence to meet global standards for societal development.<br><br><br><br></p>
				</card>
			</div>
		
		<div class="card">
				<div class="card-img card-img3">
					
				</div>
				<card class="card-body">
					<h3>Objective of the Institute</h3>
				
				<p>To impart innovative teaching and learning.
					To provide quality education with futuristic trends in engineering and technology<br><br><br><br><br><br></p>

				</card>
			</div>
		
		<div class="card"><br><br>
				<div class="card-img card-img4" >
					
				</div>
				<card class="card-body">
					<h3>Responsibilities</h3>
				
					<p> Building, maintaining a strong relationship between the Alumni Association and current students.
						Managing the online channels of communication with the alumni
						Building and maintaining the alumni database
						Identifying potential Alumni and inviting them to college for guest lectures and as visiting faculty
						Organizing events for the alumni </p>
				</card>
			</div>
	
		
	</div>

<div class="social-media">
		<i class="fa fa-linkedin" style="font-size:24px"></i>
	<i class="fa fa-twitter" style="font-size:24px"></i>
	<i class="fa fa-facebook" style="font-size:24px"></i>
		</div>
</div>



	
<footer>
<p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>	
</footer>
<script type="text/javascript">
	document.title="Course";
</script>
</body>
</html>