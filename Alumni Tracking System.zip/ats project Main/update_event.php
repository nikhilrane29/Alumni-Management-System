<!doctype html>
<head>
<style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>



<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="alumni";
$id="";
$date="";
$time="";
$venue="";
$oname="";
$omobile="";
$oemail="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

//connect to mysql database
try{
$conn =mysqli_connect($servername,$username,$password,$dbname);
}catch(MySQLi_Sql_Exception $ex){
echo("error in connecting");
}
//get data from the form
function getData()
{
$data = array();

$data[0]=$_POST['id'];
$data[1]=$_POST['date'];
$data[2]=$_POST['time'];
$data[3]=$_POST['venue'];
$data[4]=$_POST['oname'];
$data[5]=$_POST['omobile'];
$data[6]=$_POST['oemail'];
return $data;
}
//search
if(isset($_POST['search']))
{
$info = getData();
$search_query="SELECT * FROM evshow WHERE id = '$info[0]'";
$search_result=mysqli_query($conn, $search_query);
if($search_result)
{
if(mysqli_num_rows($search_result))
{
while($rows = mysqli_fetch_array($search_result))
{
$id = $rows['id'];
$date = $rows['date'];
$time = $rows['time'];
$venue = $rows['venue'];
$oname = $rows['oname'];
$omobile = $rows['omobile'];
$oemail = $rows['oemail'];

}
}else{
echo("no data are available");
}
} else{
echo("result error");
}

}
//insert
if(isset($_POST['insert'])){
$info = getData();
$insert_query="INSERT INTO `evshow`(`id`,`date`, `time`, `venue`, `oname`,`omobile`, `oemail`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]','$info[5]','$info[6]')";
try{
$insert_result=mysqli_query($conn, $insert_query);
if($insert_result)
{
if(mysqli_affected_rows($conn)>0){

echo("data inserted successfully");

}else{
echo("data are not inserted");
}
}
}catch(Exception $ex){
echo("error inserted".$ex->getMessage());
}
}
//delete
if(isset($_POST['delete'])){
$info = getData();
$delete_query = "DELETE FROM `evshow` WHERE id = '$info[0]'";
try{
$delete_result = mysqli_query($conn, $delete_query);
if($delete_result){
if(mysqli_affected_rows($conn)>0)
{
echo("data deleted");
}else{
echo("data not deleted");
}
}
}catch(Exception $ex){
echo("error in delete".$ex->getMessage());
}
}
//edit
if(isset($_POST['update'])){
$info = getData();
$update_query="UPDATE `evshow` SET `date`='$info[1]',time='$info[2]',venue='$info[3]',oname='$info[4]',omobile='$info[4]',oemail='$info[4]'WHERE id = '$info[0]'";
try{
$update_result=mysqli_query($conn, $update_query);
if($update_result){
if(mysqli_affected_rows($conn)>0){
echo("data updated");
}else{
echo("data not updated");
}
}
}catch(Exception $ex){
echo("error in update".$ex->getMessage());
}
}

?>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>
	
		
		 <div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
		  <a href="upload.php">Upload post</a>
		  <a href="update_event.php">Update Event</a>
		  <a href="select.php">Register student</a>
		  <a href="Event show.php">Event Show</a>



		</div>
	
<form method ="post" action="update_event.php">

<link rel="stylesheet" href="./css/upload.css" type="text/css">
    
	<div class="body-content">
	   <div class="module">
	   <form action="" method="POST">
            <!-- <h1 style="color:rgb(32, 8, 8)">Generate Mails</h1> -->
			<!-- <p style="color:rgb(32, 20, 20)">ID</p> -->

<!-- <input type="number" placeholder="ID" name="id" value="<?php echo($id);?>"><br><br required="true"></p>
<p style="color:rgb(32, 20, 20)">Date Of Event</p>
<input type="text" placeholder="Date" name="date" value="<?php echo($date);?>"><br><br required="true"></p>

<p style="color:rgb(32, 20, 20)">Time Of Event</p>
<input type="text" placeholder="Time" name="time" value="<?php echo($time);?>"><br><br required="true"></p>
<input type="text" placeholder="Venue" name="venue" value="<?php echo($venue);?>"><br><br required="true"></p>
<input type="text" placeholder="Organizer Name" name="oname" value="<?php echo($oname);?>"><br><br required="true"></p>
<input type="text" placeholder="Organizer Mobile" name="omobile" value="<?php echo($omobile);?>"><br><br required="true"></p>
<input type="text" placeholder="Organizer Email" name="oemail" value="<?php echo($oemail);?>"><br><br required="true"></p> -->

  <h1 style="color:black">Event Details</h1>

<input type="number" name="id" placeholder="id" value="<?php echo($id);?>"><br><br>
<input type="text" name="date" placeholder="date" value="<?php echo($date);?>"><br><br>
<input type="text" name="time" placeholder="time" value="<?php echo($time);?>"><br><br>
<input type="text" name="venue" placeholder="venue" value="<?php echo($venue);?>"><br><br>
<input type="text" name="oname" placeholder="organizer Name" value="<?php echo($oname);?>"><br><br>
<input type="text" name="omobile" placeholder="organizer mobile" value="<?php echo($omobile);?>"><br><br>
<input type="text" name="oemail" placeholder="organizer email" value="<?php echo($oemail);?>"><br><br>

<div>
<!-- <input type="submit" name="insert" value="Add">
<input type="submit" name="delete" value="Delete">
<input type="submit" name="update" value="Update">
<input type="submit" name="search" value="Find"> -->

<input type="submit" value="ADD NEW" name="insert" class="btn btn-block btn-primary" />
<button type="submit" value="DELETE" name="delete" class="btn btn-default">Delete</button>
<button type="submit" value="UPDATE" name="update" class="btn btn-default">Update</button>
<button type="submit" value="FIND" name="search" class="btn btn-default">Find</button>


</div>
</form>
</body>
</html>
