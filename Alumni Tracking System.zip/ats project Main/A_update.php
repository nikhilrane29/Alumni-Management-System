
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<!-- <link rel="stylesheet" type="text/css" href="css/New Alumni.css"> -->

</head>


<body class="body">
	<header class="mainheader">
		<img src="images/logo.png">
		<content id="search">
			<form>
				<input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
			</form>

		</content>
		<nav>
			<ul>
				<!-- <li><a href="index.php">Home</a></li>
				<li><a href="About us.php">About us</a></li>
				<li><a href="Alumni login.php">Alumni Login</a></li>
				<li><a href="New Alumni.php">New Alumni</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="Admin login.php">Admin Login</a></li> -->

			</ul>
		</nav>
	</header>
	<!----------------------------------------------------------------------------------------------->
	<link rel="stylesheet" href="./css/New Alumni.css" type="text/css">
	<div class="body-content">
		<div class="module">
		
			<h1 style="color:Black">Alumni Update Information</h1>
			<form class="form" action="signupconnect.php " method="POST" >
				<div class="alert alert-error"></div>


				<input type="text" placeholder="FullName" name="fname" required="true"></p>
				<!-- <input type="text" placeholder="UserName" name="uname" required="true"></p> -->
				<!-- <input type="password" placeholder="Password" name="pwd" required="true"></p> -->
				<!-- <input type="password" placeholder="Confirm Password" name="cpwd" required="true"></p> -->
				<input type="text" placeholder="Department Name" name="dname" required="true"></p>
				<input type="text" placeholder="Admission Year" name="addyr" required="true"></p>
				<input type="text" placeholder="Passout Year" name="passyr" required="true"></p>
				<input type="text" placeholder="Current Location" name="clocation" required="true"></p>
				<input type="text" placeholder="Address" name="address" required="true"></p>
				<input type="date" placeholder="Date Of Birth" name="dob" required="true"></p>
				<input type="email" placeholder="E-mail" name="email" required="true"></p>
				<input type="number" placeholder="Phone" name="phno" required="true"></p>
				<input type="text" placeholder="Award(if Any)" name="award" required="true"></p>

				<input type="submit" value="Update" name="reg" class="btn btn-block btn-primary" />
				<!-- <a href="select.php"  name="check" class="button">Check Out>></a> -->
			</form>		

			</form>
		</div>
	</div>
</body>

</html>

