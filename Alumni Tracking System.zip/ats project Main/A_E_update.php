<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>upload post</title>
    <style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>
<body>
<!-- --------------------------------nav bar----------------- -->
<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>
	
		
		 <div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
		  <a href="upload.php">Upload post</a>
		  <a href="update_event.php">Update Event</a>
		  <a href="select.php">Register student</a>
		  <a href="Event show.php">Event Show</a>



		</div>
		
		
		</div>
		

<!-- --------------------------------------------------------------------------------- -->
<?php $i = $_GET['i']; ?>
    </style>
    <link rel="stylesheet" href="./css/New Alumni.css" type="text/css">
	<div class="body-content">
		<div class="module">
		
			<h1 style="color:Black">Alumni Upadate info</h1>
			<form class="form" action=" " method="POST" >
				<div class="alert alert-error"></div>

				<!-- <label>Choose an Profile pic:</label><br>
		   <input type="file" placeholder="image"   name="image" required="true"></p> -->
           <input type="text"  name="Id" value="<?php echo $i;?>" required="true"></p>
				<input type="text" placeholder="FullName" name="fname" required="true"></p>
				<!-- <input type="text" placeholder="UserName" name="uname" required="true"></p>
				<input type="password" placeholder="Password" name="pwd" required="true"></p>
				<input type="password" placeholder="Confirm Password" name="cpwd" required="true"></p> -->
				<input type="text" placeholder="Department Name" name="dname" required="true"></p>
				<input type="text" placeholder="Admission Year" name="addyr" required="true"></p>
				<input type="text" placeholder="Passout Year" name="passyr" required="true"></p>
				<input type="text" placeholder="Current Location" name="clocation" required="true"></p>
				<input type="text" placeholder="Address" name="address" required="true"></p>
				<input type="date" placeholder="Date Of Birth" name="dob" required="true"></p>
				<input type="email" placeholder="E-mail" name="email" required="true"></p>
				<input type="number" placeholder="Phone" name="phno" required="true"></p>
				<input type="text" placeholder="Award(if Any)" name="award" required="true"></p>

				<input type="submit" value="update" name="up" class="btn btn-block btn-primary" />
				<a href="select.php"  name="check" class="button">Check Out>></a>
			</form>		

			<!-- <form class="form" action="login1.php" method="post" enctype="multipart/form-data" autocomplete="off"> -->
			<!-- <input type="submit" value="Back to Login" name="login" class="btn btn-block btn-primary" /> -->
			</form>
            <?php
			$con = mysqli_connect("localhost","root","","alumni");
			mysqli_query($con,"update from info where i='$i'");
	        if(isset($_POST['up'])){
				
         $Id = $_POST['Id'];
         $fname = $_POST['fname'];
        // $uname = $_POST['uname'];
        // $pwd = $_POST['pwd'];
        // $cpwd = $_POST['cpwd'];
        $dname = $_POST['dname'];
        $addyr = $_POST['addyr'];
        $passyr = $_POST['passyr'];
        $clocation = $_POST['clocation'];
        $address = $_POST['address'];
        $dob = $_POST['dob'];
        $email = $_POST['email'];
        $phno = $_POST['phno'];
        $award = $_POST['award'];

        $query = "update into info(fname,uname,pwd,cpwd,dname,addyr,passyr,clocation,address,dob,email,phno,award) values('$fname','$uname','$pwd','$cpwd','$dname','$addyr','$passyr','$clocation','$address','$dob','$email','$phno','$award')";
        mysqli_query($con,"update info set fname='$fname',dname='$dname',addyr='$addyr',passyr='$passyr',clocation='$clocation',address='$address',dob='$dob',email='$email',phno='$phno',award='$award' where Id='$Id'");
        $result = mysqli_query($con,$query);
        echo 'Registration Successfull';
        
        header("location:select.php");
    }
	


            ?>
		</div>
	</div>
	<!--------------------------------------------------------------------
</body>
</html>






