
<!DOCTYPE html>
<html lang="en">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1">  -->
<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1/">
	<link rel = "stylesheet" href= "http://www.w3schools.com/lib/w3.css/">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="HandheldFriendly" content="true">
 <!-- <meta name="Keywords" content="SSBT COET BAMBHORI,JALGAON"> -->
 <!-- <meta name="author" content="---"> -->
 <link rel="stylesheet" type="text/css" href="css/style.css">
<script src="javascript/js.js="></script>

</head>
<body class="body">
<header class="mainheader">
	<div>
	<img src="images/logo.png">
	
	
	<content id="search">

		<form>
  <input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
</form>
<h2 style="color:rgb(153, 4, 4);">ALUMNI TRACKING SYSTEM</h2>
	</content>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="About us.php">About us</a></li>
			<li><a href="Alumni login.php">Alumni Login</a></li>
			<li><a href="New Alumni.php">New Alumni</a></li>
			<li><a href="Admin login.php">Admin Login</a></li>
			<li><a href="contact.php">Contact</a></li>

			
		</ul> 
	</nav>
</header>
<br>
<div class="slideshow-container">

<div class="iambrpslides fade">
  <div class="numbertext">01 / 03</div>
  <img src="./images/a.jpg">
 </div>

<div class="iambrpslides fade">
  <div class="numbertext">02 / 03</div>
  <img src="./images/b.jpg">
  </div>

<div class="iambrpslides fade">
  <div class="numbertext">03 / 03</div>
  <img src="./images/c.jpg">
</div>


</div>


<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("iambrpslides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2500); // This is for Changing image every 2.5 seconds
}
</script>

<br>
		
		<script type="text/javascript">
  document.title="Home";
</script>
		
				
<script src="scripts/slider.js"></script>
<div class="mainContent">
	<div class="Content">
		<article class="topContent">
			<header>
			 <h3><a href="#" title="My First Post">Welcome To Alumni Tracking System </a>	</h3>  
			</header>
			
			<content>
<p>Web Based Online Alumni Management System helps institutes strategically build and maintain their alumni network, by facilitating engagement, community-building, networking, communications and many other methods. And thus a secondary array of positive marketing takes place. With Alumni Management System, the Alumni data can be centralized and combined to use it in any future endeavours.

	Alumni System is a online application system which can act as a interactive medium between the old student and the School, College, University or institution. An Online Alumni System is a web based application which helps the institutions to track old students and to track them for future endeavours. At the same time it helps the alumni to communicate with the institution, may be a school, or college or a university and with the old batch mates. The system has been developed keeping in mind about the changing scenario of the market.

</p>
			</content>
		</article>

		<article class="bottomContent">
			<header>
			<h3><a href="#" title="Pathway Programme">Pathway Programme</a>	</h3>  
			</header>
			
			<content>
<p>Pass out students of SSBT's College of Engineering & Technology, Bambhori, Jalgaon has formed an Alumni Association in 2003 under the name 'Shram Sadhana Engineering Alumni', abbreviated as SEA.
We focus in giving you the best.

</p>
			</content>
		</article>

		
	</div>
</div>
<aside class="top-sidebar">
	<article>
		<marquee behavior="right" direction="left"><h3>Latest updates!</h3></marquee>
		<p>Check out our open placement session and Events!</p>
	</article>
</aside>

<aside class="middle-sidebar">
	<article>
		<h3>Join us today</h3>
		<p>We appreciate your interest in Alumni Registration - Please create your SSCOET Account by clicking here.....</p>
	</article>
</aside>

<aside class="buttom-sidebar">
	<article>
		<h3>Upcoming Events</h3>

		<a href="upcomming event.php" class="button">Check Out>></a>

	</article>
</aside>
<footer class="mainFooter">
	<p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>
	
</footer>

</body>
</html>