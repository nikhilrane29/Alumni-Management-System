<?php
$con = mysqli_connect("localhost","root","","alumni");
$uname = $_POST['uname'];
$pwd = $_POST['pwd'];

$query = "select * from info  where uname = '$uname'  and pwd = '$pwd' ";
$result = mysqli_query($con,$query);

if($_POST['uname']=="$uname" and $_POST['password']=="$pwd" ){
			 
    header("location:success.php?message=Successful login");
}
else{
    echo "login failed";
    
}




?>