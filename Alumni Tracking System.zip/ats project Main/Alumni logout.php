<?php session_start();
if(empty($_SESSION['id']));
header('Location:Alumni login.php');

?>
<!DOCTYPE html>
<html>
<body>
<div style="width:150px;margin:auto;height:500px;margin-top:300px"></div>
<?php
include('signupconnect.php');
session_destroy();
echo '<meta http-equiv="refresh" content="2;url=Alumni login.php">';
echo '<progress max=100><strong>progress: 60%done.</strong></progress><br>';

echo '<span class="itext">Logging out please wait............!</span>';
?>

</body></html>