
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>upload post</title>
    <style media="screen">
  #custom-button {
  padding: 10px;
  color: white;
  background-color: #009578;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

#custom-button:hover {
  background-color: #00b28f;
}

#custom-text {
  margin-left: 10px;
  font-family: sans-serif;
  color: #aaa;
}

    </style>
</head>
<body>
<!-- --------------------------------nav bar----------------- -->
<style>
		body {
		  margin: 0;
		  font-family: Arial, Helvetica, sans-serif;
		}
		
		.topnav {
		  overflow: hidden;
		  background-color: #333;
		}
		
		.topnav a {
		  float: left;
		  color: #f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}
		
		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}
		
		.topnav a.active {
		  background-color: #04AA6D;
		  color: white;
		}
		</style>
	
		
		 <div class="topnav"> 
		   <a class="active" href="index.php">Home</a> 
		  <a href="upload.php">Upload post</a>
		  <a href="update_event.php">Update Event</a>
		  <a href="select.php">Register student</a>
		  <a href="Event show.php">Event Show</a>



		</div>
		
		
		</div>
		












<?php
//display data here
$con = mysqli_connect("localhost","root","","alumni");
$s= mysqli_query($con,"select * from info");

?>
  <div class="danger">
  <!-- <h2>Register Student</h2> -->
  <!-- <h1 style="color:greay text-align = center";>Register Student</h1> -->
  <h1 style="color:greay" align="center">Register Student</h1> 
  <table class="table">
    <thead>
    <tr class="danger">
        <th>ID</th>
        <th>Full Name</th>
        <th>Department</th>
        <th>Add yr</th>
        <th>passout yr</th>
        <th>Current loc.</th>
        <th>Address</th>
        <th>Dob</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Award</th>
        <th>Add New</th>
        <th>Remove</th>
        <th>Update</th>
  </tr> 
    </thead>
    

  <?php
// fetch data
while($result = mysqli_fetch_array($s))
{
  ?>
  <tr class="warning">
    <td><?php echo $result['Id']; ?> </td>
    <td><?php echo $result['fname']; ?> </td>
    <td><?php echo $result['dname']; ?> </td>
    <td><?php echo $result['addyr']; ?> </td>  
    <td><?php echo $result['passyr']; ?> </td>
    <td><?php echo $result['clocation']; ?> </td>
    <td><?php echo $result['address']; ?> </td>
    <td><?php echo $result['dob']; ?> </td>
    <td><?php echo $result['email']; ?> </td>
    <td><?php echo $result['phno']; ?> </td>
    <td><?php echo $result['award']; ?> </td>
    
    <td><a href="New Alumni.php">New Record</a></td>
    <td><a href="delete.php?i=<?php echo $result["Id"]; ?>">Delete</a> </td>


    <td><a href="A_E_update.php?i=<?php echo $result["Id"]; ?>">Update</a> </td>


  </tr> 
<?php
}
?>
</div>
</table>
</script>
</body>
</html>