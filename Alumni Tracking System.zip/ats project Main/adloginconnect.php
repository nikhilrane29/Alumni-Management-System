<?php  
	$conn = mysqli_connect("localhost","root","","alumni");
	
	$uname = $_POST['uname'];
	$password = $_POST['password'];

	$query = "select * from login where uname ='$uname' and password ='$password' ";
	$result = mysqli_query($conn,$query);

		if($_POST['uname']=="Niks11" and $_POST['password']=="Nikhil1234" ){
			 
			header("location:Success.php?message=Successful login");
		}
		else{
			echo "login failed";
			
		}
	
	


?>