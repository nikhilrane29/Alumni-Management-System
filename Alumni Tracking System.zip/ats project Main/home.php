<?php session_start();
if(empty($_SESSION['id']));
header('Location:Admin login.php');

?>
<!DOCTYPE html>
<html>
<head>
<title>home page</title>
</head>
<body>
<div style="float:right"><button>Logout</button></div>
<h1>Welcome to home Page</h1>

</body></html>