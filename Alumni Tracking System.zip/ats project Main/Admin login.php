<!DOCTYPE html>
<html lang="en">
<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">
<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
<!-- <meta name="Keywords" content="SSBT COET BAMBHORI,JALGAON"> -->
 <!-- <meta name="author" content="-----"> -->
 <link rel="stylesheet" type="text/css" href="css/style.css">
<script src="javascript/js.js="></script>
<script src="javascript/login.js"></script> 

</head>
<body class="body">
<header class="mainheader">
	<img src="images/logo.png">
	<content id="search">
		<form>
  <input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
</form>

	</content>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="About us.php">About us</a></li>
			<li><a href="Alumni login.php">Alumni Login</a></li>
			<li><a href="New Alumni.php">New Alumni</a></li>
			<li><a href="Admin login.php">Admin Login</a></li>
			<li><a href="contact.php">Contact</a></li>

		</ul> 
	</nav>
</header>

<div class="container">
	  <div class="main">
	  
		<h3>Admin Login</h3><hr/>
		<form action="adloginconnect.php" method="post" >
		<form id="form_id" method="post" name="myform">
		  <strong>User Name :</strong></br>
		  <input type="text" name="uname" id="username"/></br>
 
		   <strong>Password :</strong></br>
		  <input type="password" name="password" id="password"/></br>
 
		  <input type="SUBMIT" class="btn" value="Login"></br>
		</form>
	  </div>
	 
	   <div class="fugo">
		 <a href="images/login_photo.jpg"><img src="images/login_photo.jpg" /></a>
		 </form>
	  </div>
	</div>

<footer class="mainFooter">
<p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>	
</footer>
<!-- <script type="text/javascript"> -->
  <!-- document.title="Login"; -->
<!-- </script> -->
</body>
</html>