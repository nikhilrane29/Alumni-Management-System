<!DOCTYPE html>
<html lang="en">
<head>
	<title>Alumni tracking System</title>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Keywords" content="SSBT COET BAMBHORI,JALGAON">
 <meta name="author" content="---">
 <link rel="stylesheet" type="text/css" href="css/style.css">
<script src="javascript/js.js"></script>
<script src="javascript/validatename.js"></script>
<style>
  @import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);

body { background:#d8dbf0;}
form { max-width:420px; margin:50px auto; }

.feedback-input {
  color:white;
  font-family: Helvetica, Arial, sans-serif;
  font-weight:500;
  font-size: 18px;
  border-radius: 5px;
  line-height: 22px;
  background-color: transparent;
  border:2px solid #CC6666;
  transition: all 0.3s;
  padding: 13px;
  margin-bottom: 15px;
  width:100%;
  box-sizing: border-box;
  outline:0;
}

.feedback-input:focus { border:2px solid #CC4949; }

textarea {
  height: 150px;
  line-height: 150%;
  resize:vertical;
}

[type="submit"] {
  font-family: 'Montserrat', Arial, Helvetica, sans-serif;
  width: 100%;
  background:#CC6666;
  border-radius:5px;
  border:0;
  cursor:pointer;
  color:white;
  font-size:24px;
  padding-top:10px;
  padding-bottom:10px;
  transition: all 0.3s;
  margin-top:-4px;
  font-weight:700;
}
[type="submit"]:hover { background:#CC4949; }
</style>
</head>
<body class="body">
<header class="mainheader">
	<img src="images/logo.png">
	<content id="search">
		<form>
  <input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
</form>

	</content>
<nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="About us.php">About us</a></li>
      <li><a href="Alumni login.php">Alumni Login</a></li>
			<li><a href="New Alumni.php">New Alumni</a></li>
      <li><a href="Admin login.php">Admin Login</a></li>
      <li><a href="contact.php">Contact</a></li>

    </ul> 
  </nav>
</header>


<form
  action="https://formspree.io/f/mleabpwj" method="POST">
  <label>
    Your name
    <input type="name" class="feedback-input" name="Name">

  </label>
  <label>
    Contact No.
    <input type="Contact" class="feedback-input" name="Contact">

  </label>
  <label>
    Your email:
    <input type="email" class="feedback-input" name="_replyto">
  </label>
  <label>
    Your message:
    <textarea  class="feedback-input" name="message"></textarea>
  </label>
  <!-- your other form fields go here -->
  <button type="submit">Send</button>
</form>
<!-- <form>      
  <input name="name" type="text" class="feedback-input" placeholder="Name" />   
  <input name="email" type="text" class="feedback-input" placeholder="Email" />
  <input name="contact" type="text" class="feedback-input" placeholder="Contact No" />   
  <textarea name="text" class="feedback-input" placeholder="Message"></textarea>
  <input type="submit" value="SUBMIT"/>
</form> -->

<div class="contactinfo">
  
</content>
Contact<br>
SSBT COET BAMBHORI,JALGAON<br>
Lions Building, Shiv Colony
MT-12, Jalgaon-220976 <br>
Phone : +91-937000***3 <br>
Email :  nikhilrane25***@gamil.com <br>

</div>
<body>

  <footer class="mainFooter">
  <p>Copyright &copy <a href="https://sscoetjalgaon.ac.in/">SSBTian</a> </p>    
  </footer>
  

<!------------------------------------------------------------------------------->
<!-- <script type="text/javascript"> -->
  <!-- document.title="Contact"; -->
<!-- </script> -->
</body>

</html>