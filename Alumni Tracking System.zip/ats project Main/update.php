
<?php
include("signupconnect.php");
// $Id = $_GET['Id'];
// $uname = $_GET['uname'];
// $dname = $_GET['fname'];
// $addyr = $_GET['addyr'];
// $passyr = $_GET['passyr'];
// $clocation = $_GET['clocation'];
// $address = $_GET['address'];
// $dob = $_GET['dob'];
// $email = $_GET['email'];
// $phno = $_GET['phno'];
// $award = $_GET['award'];
        
?> 
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Alumni Tracking System</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<!-- <link rel="stylesheet" type="text/css" href="css/New Alumni.css"> -->

</head>


<body class="body">
	<header class="mainheader">
		<img src="images/logo.png">
		<content id="search">
			<form>
				<input type="text" name="search" placeholder="Search anything..." onclick="window.location.href='search.php'">
			</form>

		</content>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="About us.php">About us</a></li>
				<li><a href="Alumni login.php">Alumni Login</a></li>
				<li><a href="New Alumni.php">New Alumni</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="Admin login.php">Admin Login</a></li>

			</ul>
		</nav>
	</header>
	<!----------------------------------------------------------------------------------------------->
	<link rel="stylesheet" href="./css/New Alumni.css" type="text/css">
	<div class="body-content">
		<div class="module">
		
			<h1 style="color:Black">Update Details</h1>
			<form class="form" action="" method="POST" >
				<div class="alert alert-error"></div>

				<!-- <label>Choose an Profile pic:</label><br>
		   <input type="file" placeholder="image"   name="image" required="true"></p> -->

				<input type="text" placeholder="FullName" value="<?php echo "$fname"?>" name="fname" required="true"></p>
				<input type="text" placeholder="UserName" value="<?php echo "$uname"?>" name="uname" required="true"></p>
				<input type="password" placeholder="Password" value="" name="pwd" required="true"></p>
				<input type="password" placeholder="Confirm Password" value="" name="cpwd" required="true"></p>
				<input type="text" placeholder="Department Name" value="<?php echo "$dname"?>" name="dname" required="true"></p>
				<input type="text" placeholder="Admission Year" value="<?php echo "$addyr"?>" name="addyr" required="true"></p>
				<input type="text" placeholder="Passout Year" value="<?php echo "$passyr"?>" name="passyr" required="true"></p>
				<input type="text" placeholder="Current Location" value="<?php echo "$clocation"?>" name="clocation" required="true"></p>
				<input type="text" placeholder="Address" value="<?php echo "$address"?>" name="address" required="true"></p>
				<input type="date" placeholder="Date Of Birth" value="<?php echo "$dob"?>" name="dob" required="true"></p>
				<input type="email" placeholder="E-mail" value="<?php echo "$email"?>" name="email" required="true"></p>
				<input type="number" placeholder="Phone" value="<?php echo "$phno"?>" name="phno" required="true"></p>
				<input type="text" placeholder="Award(if Any)" value="<?php echo "$award"?>" name="award" required="true"></p>

				<input type="submit" value="Update" name="reg" class="btn btn-block btn-primary" />
				<!-- <a href="select.php"  name="check" class="button">Check Out>></a> -->
			</form>		

			<!-- <form class="form" action="login1.php" method="post" enctype="multipart/form-data" autocomplete="off"> -->
			<!-- <input type="submit" value="Back to Login" name="login" class="btn btn-block btn-primary" /> -->
			</form>
		</div>
	</div>
	
</body>

</html>

